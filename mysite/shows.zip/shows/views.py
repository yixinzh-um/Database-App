from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render,redirect, get_object_or_404
from django.views import View
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from shows.models import Genre, Show

class ShowList(LoginRequiredMixin, View):
    def get(self,request):
        gc=Genre.objects.all().count()
        sl=Show.objects.all()
        ctx={'genre_count':gc,'show_list':sl}
        return render(request, 'shows/show_list.html',ctx)

class ShowCreate(LoginRequiredMixin, CreateView):
    model=Show
    fields='__all__'
    success_url=reverse_lazy('shows:show_all')

class ShowUpdate(LoginRequiredMixin, UpdateView):
    model=Show
    fields='__all__'
    success_url=reverse_lazy('shows:show_all')

class ShowDelete(LoginRequiredMixin, DeleteView):
    model=Show
    fields='__all__'
    success_url=reverse_lazy('shows:show_all')

class GenreList(LoginRequiredMixin, View):
    def get(self,request):
        gl=Genre.objects.all()
        ctx={'genre_list':gl}
        return render(request, 'shows/genre_list.html',ctx)

class GenreCreate(LoginRequiredMixin, CreateView):
    model=Genre
    fields='__all__'
    success_url=reverse_lazy('shows:show_all')

class GenreUpdate(LoginRequiredMixin, UpdateView):
    model=Genre
    fields='__all__'
    success_url=reverse_lazy('shows:show_all')

class GenreDelete(LoginRequiredMixin, DeleteView):
    model=Genre
    fields='__all__'
    success_url=reverse_lazy('shows:show_all')